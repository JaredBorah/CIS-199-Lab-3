﻿namespace Lab3
{
    partial class Lab3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Lab3));
            this.RadiusInput = new System.Windows.Forms.Label();
            this.radiusCalc = new System.Windows.Forms.TextBox();
            this.CalcBtn = new System.Windows.Forms.Button();
            this.DiameterLbl = new System.Windows.Forms.Label();
            this.SALbl = new System.Windows.Forms.Label();
            this.VolumeLbl = new System.Windows.Forms.Label();
            this.Diameteroutput = new System.Windows.Forms.Label();
            this.SAoutput = new System.Windows.Forms.Label();
            this.Volumeoutput = new System.Windows.Forms.Label();
            this.CirclePic2 = new System.Windows.Forms.PictureBox();
            this.CirclePic = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.CirclePic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CirclePic)).BeginInit();
            this.SuspendLayout();
            // 
            // RadiusInput
            // 
            this.RadiusInput.AutoSize = true;
            this.RadiusInput.Location = new System.Drawing.Point(224, 69);
            this.RadiusInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.RadiusInput.Name = "RadiusInput";
            this.RadiusInput.Size = new System.Drawing.Size(120, 17);
            this.RadiusInput.TabIndex = 0;
            this.RadiusInput.Text = "Radius of sphere:";
            // 
            // radiusCalc
            // 
            this.radiusCalc.Location = new System.Drawing.Point(364, 66);
            this.radiusCalc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radiusCalc.Name = "radiusCalc";
            this.radiusCalc.Size = new System.Drawing.Size(132, 22);
            this.radiusCalc.TabIndex = 1;
            // 
            // CalcBtn
            // 
            this.CalcBtn.Location = new System.Drawing.Point(380, 98);
            this.CalcBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CalcBtn.Name = "CalcBtn";
            this.CalcBtn.Size = new System.Drawing.Size(100, 28);
            this.CalcBtn.TabIndex = 2;
            this.CalcBtn.Text = "Calculate";
            this.CalcBtn.UseVisualStyleBackColor = true;
            this.CalcBtn.Click += new System.EventHandler(this.CalcBtn_Click);
            // 
            // DiameterLbl
            // 
            this.DiameterLbl.AutoSize = true;
            this.DiameterLbl.Location = new System.Drawing.Point(51, 218);
            this.DiameterLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.DiameterLbl.Name = "DiameterLbl";
            this.DiameterLbl.Size = new System.Drawing.Size(65, 17);
            this.DiameterLbl.TabIndex = 3;
            this.DiameterLbl.Text = "Diameter";
            // 
            // SALbl
            // 
            this.SALbl.AutoSize = true;
            this.SALbl.Location = new System.Drawing.Point(24, 273);
            this.SALbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SALbl.Name = "SALbl";
            this.SALbl.Size = new System.Drawing.Size(91, 17);
            this.SALbl.TabIndex = 4;
            this.SALbl.Text = "Surface Area";
            // 
            // VolumeLbl
            // 
            this.VolumeLbl.AutoSize = true;
            this.VolumeLbl.Location = new System.Drawing.Point(60, 322);
            this.VolumeLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.VolumeLbl.Name = "VolumeLbl";
            this.VolumeLbl.Size = new System.Drawing.Size(55, 17);
            this.VolumeLbl.TabIndex = 5;
            this.VolumeLbl.Text = "Volume";
            // 
            // Diameteroutput
            // 
            this.Diameteroutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Diameteroutput.Location = new System.Drawing.Point(124, 217);
            this.Diameteroutput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Diameteroutput.Name = "Diameteroutput";
            this.Diameteroutput.Size = new System.Drawing.Size(133, 28);
            this.Diameteroutput.TabIndex = 6;
            // 
            // SAoutput
            // 
            this.SAoutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SAoutput.Location = new System.Drawing.Point(124, 272);
            this.SAoutput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SAoutput.Name = "SAoutput";
            this.SAoutput.Size = new System.Drawing.Size(133, 28);
            this.SAoutput.TabIndex = 7;
            // 
            // Volumeoutput
            // 
            this.Volumeoutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Volumeoutput.Location = new System.Drawing.Point(124, 321);
            this.Volumeoutput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Volumeoutput.Name = "Volumeoutput";
            this.Volumeoutput.Size = new System.Drawing.Size(133, 28);
            this.Volumeoutput.TabIndex = 8;
            // 
            // CirclePic2
            // 
            this.CirclePic2.Image = ((System.Drawing.Image)(resources.GetObject("CirclePic2.Image")));
            this.CirclePic2.Location = new System.Drawing.Point(309, 204);
            this.CirclePic2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CirclePic2.Name = "CirclePic2";
            this.CirclePic2.Size = new System.Drawing.Size(200, 185);
            this.CirclePic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.CirclePic2.TabIndex = 9;
            this.CirclePic2.TabStop = false;
            // 
            // CirclePic
            // 
            this.CirclePic.Image = ((System.Drawing.Image)(resources.GetObject("CirclePic.Image")));
            this.CirclePic.Location = new System.Drawing.Point(16, 15);
            this.CirclePic.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CirclePic.Name = "CirclePic";
            this.CirclePic.Size = new System.Drawing.Size(200, 185);
            this.CirclePic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.CirclePic.TabIndex = 10;
            this.CirclePic.TabStop = false;
            // 
            // Lab3
            // 
            this.AcceptButton = this.CalcBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 444);
            this.Controls.Add(this.CirclePic);
            this.Controls.Add(this.CirclePic2);
            this.Controls.Add(this.Volumeoutput);
            this.Controls.Add(this.SAoutput);
            this.Controls.Add(this.Diameteroutput);
            this.Controls.Add(this.VolumeLbl);
            this.Controls.Add(this.SALbl);
            this.Controls.Add(this.DiameterLbl);
            this.Controls.Add(this.CalcBtn);
            this.Controls.Add(this.radiusCalc);
            this.Controls.Add(this.RadiusInput);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Lab3";
            this.Text = "Lab3";
            ((System.ComponentModel.ISupportInitialize)(this.CirclePic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CirclePic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label RadiusInput;
        private System.Windows.Forms.TextBox radiusCalc;
        private System.Windows.Forms.Button CalcBtn;
        private System.Windows.Forms.Label DiameterLbl;
        private System.Windows.Forms.Label SALbl;
        private System.Windows.Forms.Label VolumeLbl;
        private System.Windows.Forms.Label Diameteroutput;
        private System.Windows.Forms.Label SAoutput;
        private System.Windows.Forms.Label Volumeoutput;
        private System.Windows.Forms.PictureBox CirclePic2;
        private System.Windows.Forms.PictureBox CirclePic;
    }
}

