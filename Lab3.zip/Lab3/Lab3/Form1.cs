﻿//C5608
//lab 3
//Due Date: 9/23/2018
//CIS 199-75
//This program shows how to calculate a given radius to show the Diameter, Surface Area, and the Volume of a Circle.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Lab3 : Form
    {
        public Lab3()
        {
            InitializeComponent();
        }
        // This code will Calculate a given radius to determine Diameter, Surface Area, and Volume
        private void CalcBtn_Click(object sender, EventArgs e)
        {
            double radius;//This is the radius of the circle
            double Diameter;// This is the diameter of the circle
            double SurfaceArea;//This is the surface area of the circle
            double Volume;//This is the volume of the circle

            radius = double.Parse(radiusCalc.Text);//This converts the input into a double.

            // These are the formulas that convert the radius of a circle into the Diameter, Surface Area, and Volume of a circle.
            Diameter = 2 * radius;
            SurfaceArea= 4 * Math.PI * Math.Pow(radius,2);
            Volume = (4 * Math.PI * Math.Pow(radius, 3)) / 3;

            // This is the output given for a certain radius.
            Diameteroutput.Text = $"{Diameter:F}";
            SAoutput.Text = $"{SurfaceArea:F}";
            Volumeoutput.Text = $"{Volume:F}";
        }
    }
}
